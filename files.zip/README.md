# AI-AC-CODE Python Library

This is the official Python library for interacting with the AI-AC-CODE API.

## Installation

```bash
pip install ai-ac-code
```

## Usage

```python
from ai_ac_code import Client

client = Client()

try:
    models = client.get_models()
    for model in models:
        print(f"Model: {model.name}, Provider: {model.provider}")
except Exception as e:
    print(e)
```