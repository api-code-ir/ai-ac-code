from dataclasses import dataclass
from typing import List, Optional, Union

@dataclass
class Model:
    name: str
    description: str
    provider: str
    tier: str
    community: bool
    input_modalities: List[str]
    output_modalities: List[str]
    tools: bool
    vision: bool
    audio: bool
    aliases: Optional[Union[str, List[str]]] = None
    reasoning: Optional[bool] = None
    voices: Optional[List[str]] = None
    search: Optional[bool] = None
    uncensored: Optional[bool] = None

    @classmethod
    def from_dict(cls, data: dict):
        return cls(
            name=data.get("name"),
            description=data.get("description"),
            provider=data.get("provider"),
            tier=data.get("tier"),
            community=data.get("community", False),
            input_modalities=data.get("input_modalities", []),
            output_modalities=data.get("output_modalities", []),
            tools=data.get("tools", False),
            vision=data.get("vision", False),
            audio=data.get("audio", False),
            aliases=data.get("aliases"),
            reasoning=data.get("reasoning"),
            voices=data.get("voices"),
            search=data.get("search"),
            uncensored=data.get("uncensored"),
        )