import requests
from typing import List
from .models import Model

class Client:
    BASE_API_URL = "https://api.example.com/v1"

    def __init__(self, api_key: str = None, base_url: str = None):
        self.api_key = api_key
        self.base_url = base_url or self.BASE_API_URL
        self.session = requests.Session()
        if self.api_key:
            self.session.headers.update({"Authorization": f"Bearer {self.api_key}"})

    def _request(self, method: str, endpoint: str, **kwargs):
        url = f"{self.base_url}{endpoint}"
        try:
            response = self.session.request(method, url, **kwargs)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as err:
            raise Exception(f"HTTP Error: {err.response.status_code} {err.response.reason}")
        except requests.exceptions.RequestException as err:
            raise Exception(f"Request Error: {err}")

    def get_models(self) -> List[Model]:
        data = self._request("GET", "/models")
        if data.get("status") == "success" and "models" in data:
            return [Model.from_dict(model_data) for model_data in data["models"]]
        else:
            raise Exception("Failed to fetch models or invalid API response format.")